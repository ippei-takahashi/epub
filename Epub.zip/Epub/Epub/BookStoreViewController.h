//
//  BookStoreViewController.h
//  Epub
//
//  Created by ポニー村山 on 2014/09/24.
//  Copyright (c) 2014年 IppeiTakahashi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookStoreViewController : UIViewController

@end
